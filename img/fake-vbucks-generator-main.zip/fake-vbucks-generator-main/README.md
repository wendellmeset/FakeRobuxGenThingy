# fake-vbucks-generator

This is a vbucks generator website. This generator is fake tho. It won't give you real vbucks codes lmao.

And also is my first html and css project! ggwp
